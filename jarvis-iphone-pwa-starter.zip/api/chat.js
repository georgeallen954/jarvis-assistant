import OpenAI from "openai";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const expected = process.env.JARVIS_ACCESS_CODE;
  const supplied = req.headers["x-jarvis-access"];
  if (!expected || !supplied || supplied !== expected) {
    return res.status(401).json({ error: "Access code is missing or incorrect. Set it in Setup." });
  }

  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "Please enter a message." });
  if (message.length > 6000) return res.status(413).json({ error: "Message is too long (maximum 6,000 characters)." });

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "You are JARVIS, a capable, composed, practical personal AI assistant. Use clear British English. Help with personal organisation, research, planning, learning, and business ideas. Be honest about uncertainty and never claim to have performed actions or accessed apps unless a connected tool actually did so. Do not request passwords, API keys, or payment details. Ask for confirmation before consequential external actions; this starter currently has no external action tools.",
      input: message,
      max_output_tokens: 700
    });
    return res.status(200).json({ reply: response.output_text || "I couldn't produce a text response. Please try again." });
  } catch (error) {
    console.error("JARVIS API error:", error?.status || error?.message || "unknown");
    return res.status(500).json({ error: "The AI request failed. Check your API billing, server environment variables, and model access." });
  }
}